package com.mvc_arch.model;

public class Add {
	
	
	//method in model
	public int addNumbers(int num1, int num2) {
		return num1+num2;
	}

}
