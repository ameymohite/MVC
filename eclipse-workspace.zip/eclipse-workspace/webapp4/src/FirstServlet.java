

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public FirstServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
 String name = request.getParameter("name");
		 
		 //setAttribute() method
		/* request.setAttribute("yourname", name); */ 
		 
		 //servlet 1 calls the servlet 2    ISC 
		 //DATA FROM servlet 2 IS DISPLAYED ON PAGE OF servlet 1
		 RequestDispatcher rd = request.getRequestDispatcher("SecondServlet");
		 rd.forward(request, response);
		 
		 
		 //SESSION variable
		 HttpSession sess1 = request.getSession();
		 sess1.setAttribute("yourname", name);  //for using this setAttribute, comment the above 'setAttribute'

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
	}

}
