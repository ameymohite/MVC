package com.studentapp.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.studentapp.model.DAOConnection;


@WebServlet("/loginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginController() {
        super();
    }

	//get method called when 'New Registration' link is clicked
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		
		HttpSession session = request.getSession(false); //as session variable is set once after'LOGIN' button is clicked, it is not required to set it again so it is set to 'FALSE'
		System.out.println(session);
		
		if(session.getAttribute("email")!=null) {
	
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/registration.jsp");
		rd.forward(request, response);
	} else {
		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		rd.forward(request, response);
	}
		
	} catch(Exception e) {
		e.printStackTrace();
		
		request.setAttribute("timeout", "-- YOUR SESSION IS EXPIRED -- Please Login Again");
		
		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		rd.forward(request, response);
	}
	
	}
	
	//called when 'LOGIN' button pressed
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			//for first time session is created when 'LOGIN' button clicked
			HttpSession session = request.getSession(true);
			System.out.println(session);
			
			//SESSION TIMEOUT
			session.setMaxInactiveInterval(10); //After 10 sec, the session becomes inactive if not interacted //makes session varaible value 'null'
			System.out.println(session); //displays 'null' if interacted after 10 sec on 'menu.jsp' page which is shown after successfull login
			
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
		//Database connection through 'model' class
			DAOConnection dao = new DAOConnection();
			Connection conn = dao.getConnection();
			boolean verifyLogin = dao.verifyLogin(email, password, conn);
			
			if(verifyLogin==true) {
				
				session.setAttribute("email", email);
				
				//accessed not directly and accessed through servlets
				RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/menu.jsp");
				rd.forward(request, response);
				
			} else {
				request.setAttribute("error", "!!!! INVALID Username  / Password !!!!");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			request.setAttribute("timeout", "-- YOUR SESSION IS EXPIRED -- Please Login Again");
			
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
	}

}
