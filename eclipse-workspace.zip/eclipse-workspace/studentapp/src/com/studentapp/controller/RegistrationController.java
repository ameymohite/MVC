package com.studentapp.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.studentapp.model.DAOConnection;


@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RegistrationController() {
        super();
    }

	//'See all registration' link code below
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			HttpSession session = request.getSession(false);
			System.out.println(session);
			
			if(session.getAttribute("email")!=null) {
			
		DAOConnection dao = new DAOConnection();
		Connection con = dao.getConnection();
		ResultSet results = dao.getNewReg(con);
		
		request.setAttribute("results", results);
		
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/displayReg.jsp");
		rd.forward(request, response);
	} else {
		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		rd.forward(request, response);
	}
			
		} catch(Exception e) {
			e.printStackTrace();
			
			request.setAttribute("timeout", "-- YOUR SESSION IS EXPIRED -- Please Login Again");
			
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
	}
	
	//code called when 'SAVE' button clicked after filling form details
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			HttpSession session = request.getSession(false);
			System.out.println(session);
			//System.out.println(session.getAttribute("email"));
			if(session.getAttribute("email")!=null) {
				
			String name = request.getParameter("name");
			String city = request.getParameter("city");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");
			
			if(name!=null && city!=null && email!=null && mobile!=null) { //&& name.length()>=3
			
			DAOConnection dao = new DAOConnection();
			Connection con = dao.getConnection();
			
			int recordsAdded = dao.createRegistration(name, city, email, mobile, con);
			request.setAttribute("msg", "Number of records added :"+recordsAdded);
			
			RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/registration.jsp");
			rd.include(request, response);
			
			} else {
				
				request.setAttribute("input", "## INVALID Input ##");
				
				RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/registration.jsp");
				rd.include(request, response);
				
			}
			
			
			
			} else {
				
				
				
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
