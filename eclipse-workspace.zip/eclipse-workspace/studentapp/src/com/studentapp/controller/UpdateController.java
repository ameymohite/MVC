package com.studentapp.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.studentapp.model.DAOConnection;


@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

//doGet is called when 'UPDATE' LINK is clicked in database table
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			HttpSession session = request.getSession(false);
			
			if(session.getAttribute("email")!=null) {
			
		String email = request.getParameter("emid");
		String phone = request.getParameter("phn");
		
		request.setAttribute("email", email);
		request.setAttribute("phone", phone);
		
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/updateReg.jsp");
		rd.forward(request, response);
		
		} else {
			
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
			
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
			
		}
	

	//called after clicking 'UPDATE' button on update page
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String em = request.getParameter("emailid");
		String pho = request.getParameter("phonee");
		
		System.out.println(em);
		System.out.println(pho);
		
		
		
		
		DAOConnection dao = new DAOConnection();
		Connection con = dao.getConnection();
		
		
		
		int updateRegistration = dao.updateRegistration( pho, em, con);
		System.out.println("UPDATE:::"+updateRegistration);
		
		ResultSet newReg = dao.getNewReg(con);
		request.setAttribute("results", newReg);
		
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/displayReg.jsp");
		rd.forward(request, response);
		
		
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("UPDATE NOT PERFORMED");
		}
	}

}
