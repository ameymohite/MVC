package com.studentapp.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.studentapp.model.DAOConnection;


@WebServlet("/deleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
            HttpSession session = request.getSession(false);
            
            System.out.println(session);
            System.out.println(session.getAttribute("email"));
            
            
			
			if(session.getAttribute("email")!=null) {
			String em = request.getParameter("emid");
			
			DAOConnection dao = new DAOConnection();
			Connection conn = dao.getConnection();
			
			int recordsDeleted = dao.deleteRegistration(em, conn);
			
			request.setAttribute("deleteReg", "No Of Records Deleted :"+recordsDeleted);
			
			//As 'results' variable becomes 'null' the code below fetches updated records present after deletion and re-initializes the 'results' variable
			ResultSet results = dao.getNewReg(conn);
			
			request.setAttribute("results", results);
			
			RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/webapp/views/displayReg.jsp");
			rd.include(request, response);
			
			} else {
				
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
 
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
