package com.studentapp.model;

import java.sql.*;

public class DAOConnection {
	private Connection con;
	private Statement stmnt;

	public Connection getConnection() {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Registration", "root", "test");
			
			return con;

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	
	
	public boolean verifyLogin(String email, String password, Connection con) {
		try {

			stmnt = con.createStatement();
			ResultSet results = stmnt.executeQuery(
					"select * from login_ex where email='" + email + "' and password='" + password + "' ");

			if (results.next()) {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	
	
	public int createRegistration(String name, String city, String email, String mobile, Connection con) {
		try {
			stmnt = con.createStatement();
			int noOfRecords = stmnt.executeUpdate("insert into newregistration values('"+name+"','"+city+"','"+email+"','"+mobile+"')");
			return noOfRecords;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	public ResultSet getNewReg(Connection con) {
		
		try {
			stmnt = con.createStatement();
			ResultSet results = stmnt.executeQuery("select * from newregistration");
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	
	public int deleteRegistration(String email, Connection con) {
		
		try {
			stmnt = con.createStatement();
			int nor = stmnt.executeUpdate("delete from newregistration where emailid='"+email+"'");
			//System.out.println(nor);
			return nor;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	
	//WITH Prepared Statement
	/*
public PreparedStatement updateRegistration(String phone, String email, Connection con) {
		
		try {
			System.out.println("In DAO update :"+phone);
			 System.out.println("In DAO update :"+email);
			 
		    PreparedStatement ps = con.prepareStatement(" UPDATE newregistration SET mobile = ? WHERE emailid= ? ");
		    ps.setString(1, phone);
		    ps.setString(2, email);
		    
		    ps.execute();
		// int executeUpdate = stmnt.executeUpdate("UPDATE newregistration SET mobile='"+phone+"' WHERE emailid='"+email+"' ");
			//System.out.println("executeUpdate VALUE = "+executeUpdate);
		 return ps;
		
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("NO UPDATE IN dao");
		}
		return null;
		
		//return 22;
	} 

*/
	
	//using without prepared statement
	
public int updateRegistration(String phone, String email, Connection con) {
		
		try {
			System.out.println("In DAO update :"+phone);
			 System.out.println("In DAO update :"+email);
			 
		    stmnt = con.createStatement();
		 int executeUpdate = stmnt.executeUpdate("UPDATE newregistration SET mobile='"+phone+"' WHERE emailid='"+email+"' ");
			System.out.println("executeUpdate VALUE = "+executeUpdate);
		 return executeUpdate;
		
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("NO UPDATE IN dao");
		}
		
		return 22;
	} 
	
	

}
