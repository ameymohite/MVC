

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/GetRegistration")
public class GetRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public GetRegistration() {
        super();
        
    }

	
  //'doGet()' is called directly when servlet File is runned first
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
				
				
				
				try {
					
					//MANDATORY DRIVER REQUIRED FOR jdbc ops
					Class.forName("com.mysql.jdbc.Driver");
					
					//database connection
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","test");
					Statement stmnt = con.createStatement();
					ResultSet rs = stmnt.executeQuery("select * from newregistration");
					
					//PRINTING DATABASE TABLE to HTML PAGE WITHOUT html file
					PrintWriter pw = response.getWriter();
					
					pw.println("<table border='1'>");
					
					pw.println("<tr>");
					
					pw.println("<th>");
					pw.println("NAME");
					pw.println("</th>");
					
					pw.println("<th>");
					pw.println("CITY");
					pw.println("</th>");
					
					pw.println("<th>");
					pw.println("EMAILID");
					pw.println("</th>");
					
					pw.println("<th>");
					pw.println("MOBILE");
					pw.println("</th>");
					
					pw.println("</tr>");
					
					//pw.println("")
					
					while(rs.next()) {
						pw.println("<tr>");
						
						pw.println("<td>");
						pw.println(rs.getString(1));
						pw.println("</td>");
						
						pw.println("<td>");
						pw.println(rs.getString(2));
						pw.println("</td>");
						
						pw.println("<td>");
						pw.println(rs.getString(3));
						pw.println("</td>");
						
						pw.println("<td>");
						pw.println(rs.getString(4));
						pw.println("</td>");
						
						pw.println("</tr>");
						
					}
					pw.println("</table>");
					
				} catch (Exception e) {
					
					e.printStackTrace();
					
				}
				
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		/* System.out.println(name);
		System.out.println(city);
		System.out.println(emailid);
		System.out.println(mobile); */
	
	
	
	
	
	
	}

}
