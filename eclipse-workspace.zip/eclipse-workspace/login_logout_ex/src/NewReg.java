

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/newReg")
public class NewReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Connection con;
	private static Statement stmnt;
       
    
    public NewReg() {
        super();
    }
    
    public void init() {
    	try {
    		Class.forName("com.mysql.jdbc.Driver");
    		
    		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Registration","root","test");
    		stmnt = con.createStatement();
    		
    		} catch(Exception e) {
    		e.printStackTrace();
    	}
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String name = request.getParameter("name");
		String city = request.getParameter("city");
		String email = request.getParameter("emailid");
		String mobile = request.getParameter("mobile");
		
		
		HttpSession sess2 = request.getSession(false); //username becomes 'null' here after logout
		String username = (String)sess2.getAttribute("emails");
		
		
		
		if(username!=null) {
		
		try {
			
			stmnt.executeUpdate("insert into newregistration values('"+name+"','"+city+"','"+email+"','"+mobile+"')");
			
			//Does not goes to blank page after submitting the data through above form and remains on same page
			RequestDispatcher rd11 = request.getRequestDispatcher("WEB-INF/webapp/views/registration.html");
			rd11.include(request, response);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		} else {
			
			RequestDispatcher rd12 = request.getRequestDispatcher("index.html");
			rd12.forward(request, response);
			
		}
		
		} catch(Exception e) {
			
			RequestDispatcher rd13 = request.getRequestDispatcher("index.html");
			rd13.forward(request, response);
			
			e.printStackTrace();
		}
	
	}
	

}
