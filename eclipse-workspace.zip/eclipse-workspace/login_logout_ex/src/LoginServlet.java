

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	private Statement stmnt;
	
	
	public void init(ServletConfig config) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Registration","root","test");
			stmnt = con.createStatement();
			
			
		} catch (Exception e) {
				e.printStackTrace();
		}
		
		
	}
       
    
    public LoginServlet() {
        super();
    }

	
    //this method is called when clicked on link
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		//session variable used for login and logout
		HttpSession sess1 = request.getSession(true); //while login it is set to TRUE
		
		
		try {
			ResultSet results = stmnt.executeQuery("select * from login_ex where email='"+email+"' and password='"+password+"' ");
			
			if(results.next()) {
				
				//'sess1' variable value initialised
				sess1.setAttribute("emails", email);
				
				
				
		//if there is valid email and password entered in form present in database then go to 'registration.html' page		
				RequestDispatcher rd1 = request.getRequestDispatcher("WEB-INF/webapp/views/registration.html");
				rd1.forward(request, response);
				
			}else {
				RequestDispatcher rd2 = request.getRequestDispatcher("index.html");
				rd2.include(request, response);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
