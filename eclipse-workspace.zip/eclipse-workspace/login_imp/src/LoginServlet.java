

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection con;
	private Statement stmnt;
	
       
       public LoginServlet() {
        super();
    }
       
       //'init()' used only once when tomcat server is started each time
       public void init() {
    	   System.out.println("from init method");
    	   
    	   try {
    		   Class.forName("com.mysql.cj.jdbc.Driver");
    		   
    		   //database connection
			   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","test");
			   stmnt = con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
       }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("from get");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String email = request.getParameter("emailid");
		String password = request.getParameter("password");
		
		try {
		
		ResultSet rs = stmnt.executeQuery(" select * from login where Emailid='"+email+"' and Password='"+password+"' ");
		if(rs.next()) {
			System.out.println("!!!!WELCOME!!!!");
			
			RequestDispatcher rd1 = request.getRequestDispatcher("newRegistration.html");
			rd1.forward(request, response);
			
		}
		else {
			System.out.println("INVALID username and password");
			
			RequestDispatcher rd2 = request.getRequestDispatcher("index.html");
			rd2.include(request, response);
		}
		
	}catch(Exception e) {
		
		e.printStackTrace();
		
	}

}
}
